﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceShooterX
{
    public partial class Form1 : Form
    {
        //Boolean Variables
        bool isMouseHold = false;
        bool isShooting = true;


        // Stats are not configurable here -- you can edit them in the difficulty code found at the bottom
        int score = 0;
        int highScore = 0;
        int alienSpd = 2;
        int lastDifficultyScore = 0;

        // Score per kill
        int scorePerKill = 10;

        // Max speed achievable in difficult scaling
        int maxAlienSpd = 10;

        // Score in which the speed of the aliens will increase by 1
        int diffIncrement = 50;

        //milliseconds btween shooting
        int fireCooldown = 5;

        Random rand = new Random();
        Timer cooldownTimer = new Timer();

        List<PictureBox> bullets = new List<PictureBox>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.DoubleBuffered = true;

            //Create Cursor for CoolDown
            Cursor.Clip = this.RectangleToScreen(this.ClientRectangle);
            cooldownTimer.Interval = fireCooldown;
            cooldownTimer.Tick += CooldownTimer_tick;

            //Progress bar setup
            cooldownBar.Maximum = 50;
            cooldownBar.Value = 50;

            highScore = Properties.Settings.Default.HighScore;
            //Questionables
            //lblScore.Text = "Score: " + score + "High Score:" + highScore;

            gameTimer.Start();
            player.BringToFront();

        }

        private void Form1_FormedClosed(object sender, FormClosedEventArgs e)
        {
            //Release Mouse
            Cursor.Clip = Rectangle.Empty;
        }

        //Mouse Movement -> Keep Player inside Window/Client Form
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            int leftMovement = e.X - (player.Width / 2);
            if (leftMovement < 0)
                leftMovement = 0;
            if (leftMovement > this.ClientSize.Width - player.Width)
                leftMovement = this.ClientSize.Width - player.Width;
            player.Left = leftMovement;
        }

        //Allows mouse shooting -> hold to rapid-fire
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                isMouseHold = true;
        }


        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                isMouseHold = false;
        }

        private void CooldownTimer_tick(object sender, EventArgs e)
        {
            if (cooldownBar.Value < 50)
            {
                cooldownBar.Value += 10;
            }

            else
            {
                cooldownTimer.Stop();
                isShooting = true;
                this.Cursor = Cursors.Default;
            }
        }

        private void ShootBullet()
        {
            if (!isShooting)
                return;

            isShooting = false;
            cooldownBar.Value = 0;
            this.Cursor = Cursors.WaitCursor;
            cooldownTimer.Start();

            //Bullet Creation
            PictureBox bullet = new PictureBox();
            bullet.Size = new Size(5, 25);
            bullet.BackColor = Color.YellowGreen;
            bullet.Left = player.Left + (player.Width / 2) - (bullet.Width / 2);
            bullet.Top = player.Top - (bullet.Height/2);
            bullet.Tag = "bullet";
            this.Controls.Add(bullet);
            bullets.Add(bullet);
            bullet.BringToFront();

        }

        private void gameTimer_tick(object sender, EventArgs e)
        {
            //Auto Fire while held
            if (isMouseHold && isShooting)
                ShootBullet();

            //Move Bullets
            foreach (PictureBox pb in bullets.ToList())
            {
                pb.Top -= 20;

                if (pb.Top < 0)
                {
                    bullets.Remove(pb);
                    this.Controls.Remove(pb);
                }
            }

            //Movement of Alients and Hitting Aliens
            foreach (PictureBox alien in this.Controls.OfType<PictureBox>())
            {
                if ((string)alien.Tag == "alien")
                {
                    alien.Top += alienSpd;

                    if (alien.Bounds.IntersectsWith(player.Bounds))
                    {
                        GameOver();
                        return;
                    }

                    foreach (PictureBox pb in bullets.ToList())
                    {
                        if (pb.Bounds.IntersectsWith(alien.Bounds))
                        {
                            //Reset Alients instead removing them
                            alien.Top = -alien.Height;
                            alien.Left = rand.Next(20, this.ClientSize.Width - alien.Width - 20);


                            //Remove bullets
                            this.Controls.Remove(pb);
                            bullets.Remove(pb);

                            score += scorePerKill;
                            //lblScore.Text = "Score: " + score + "High Score:" + highScore;
                        }
                    }

                    //Respawn
                    if (alien.Top > this.ClientSize.Height)
                    {
                        alien.Top = rand.Next(-20, -10);
                        alien.Left = rand.Next(20, this.ClientSize.Width - alien.Width - 20);
                    }
                }
            }

            if (score % diffIncrement == 0 && score != 0 && score != lastDifficultyScore && alienSpd <= maxAlienSpd)
            {
                lastDifficultyScore = score;
                alienSpd = alienSpd + (score / diffIncrement);
            }


        }


        private void GameOver()
        {
            gameTimer.Stop();
            cooldownTimer.Stop();

            if (score > highScore)
            {
                highScore = score;
                Properties.Settings.Default.HighScore = highScore;
                Properties.Settings.Default.Save();

            }

            DialogResult results = MessageBox.Show(
            "Game Over!\n\nScore: " + score +
            "\nHigh Score: " + highScore +
            "\n\nPlay Again?",
            "Game Over",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Information);

            if (results == DialogResult.Yes)
                GameRestart();
            else
                this.Close();


        }

        private void GameRestart()
        {
            foreach (Control c in this.Controls.OfType<PictureBox>().ToList())
            {
                if ((string)c.Tag == "bullet")
                    this.Controls.Remove(c);
            }
            bullets.Clear();

            //Reset Variables
            score = 0;
            alienSpd = 2;
            isShooting = true;
            cooldownBar.Value = 50;
            //lblScore.Text = "Score: " + score + "High Score:" + highScore;

            //reset our alien Position
            foreach (PictureBox alien in this.Controls.OfType<PictureBox>().ToList())
            {
                if ((string)alien.Tag == "alien")
                {
                    alien.Top = rand.Next(0, 20);
                    alien.Left = rand.Next(20, this.ClientSize.Width - alien.Width - 20);
                }
            }


        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            
        }

        private void lblScore_Click(object sender, EventArgs e)
        {

        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            // Changes the given stats of the aliens
            alienSpd = 1;
            lastDifficultyScore = 0;
            scorePerKill = 10;
            maxAlienSpd = 3;
            diffIncrement = 100;
            fireCooldown = 3;

            // Hides the menu and begins the game
            this.menuPanel.Visible = false;
            this.menuPanel.Dock = DockStyle.None;
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {
            // Changes the given stats of the aliens
            alienSpd = 2;
            lastDifficultyScore = 0;
            scorePerKill = 15;
            maxAlienSpd = 5;
            diffIncrement = 150;
            fireCooldown = 5;

            // Hides the menu and begins the game
            this.menuPanel.Visible = false;
            this.menuPanel.Dock = DockStyle.None;
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            // Changes the given stats of the aliens
            alienSpd = 3;
            lastDifficultyScore = 0;
            scorePerKill = 20;
            maxAlienSpd = 8;
            diffIncrement = 180;
            fireCooldown = 5;

            // Hides the menu and begins the game
            this.menuPanel.Visible = false;
            this.menuPanel.Dock = DockStyle.None;
        }

        private void btnNight_Click(object sender, EventArgs e)
        {
            // Changes the given stats of the aliens
            alienSpd = 5;
            lastDifficultyScore = 0;
            scorePerKill = 25;
            maxAlienSpd = 10;
            diffIncrement = 200;
            fireCooldown = 5;

            // Hides the menu and begins the game
            this.menuPanel.Visible = false;
            this.menuPanel.Dock = DockStyle.None;
        }

        private void menuPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}